package com.test.flexion;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class FlexionCodeReviewMain {

	public static String[] temparatures = {"kelvin", "celsius", "fahrenheit", "rankine"};
	public static String[] volumes = {"liters", "tablespoons", "cubic-inches", "cups","cubic-feet", "gallons"};
	private static String DEFAULT_STATUS = "invalid";
	
	public static void main(String[] args) {
		
		//Reader
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter input numerical value:");
		String inputMeasure, targetMeasure, studentResponse, output = DEFAULT_STATUS;
		float inputNumericVal;
		
		try {
			inputNumericVal = Float.parseFloat(reader.readLine());
			System.out.println("Numerical value:"+inputNumericVal);
			
			System.out.print("Please enter input unit of measure:");
			inputMeasure = reader.readLine().trim().toLowerCase();
			
			System.out.print("Please enter target unit of measure:");
			targetMeasure = reader.readLine().trim().toLowerCase();
			
			System.out.print("Please enter student response:");
			studentResponse = reader.readLine();
			
			output = calculate(inputMeasure, targetMeasure, inputNumericVal,  studentResponse, output);
			
			System.out.println("Output:" + output +" studentResponse:"+ studentResponse);
			if (output.equalsIgnoreCase(DEFAULT_STATUS)){
				System.out.println(DEFAULT_STATUS);
			}else if (output.trim().equals(studentResponse)){
				System.out.println("correct");
			}else {
				System.out.println("incorrect");
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * 
	 * 
	 * 
	 * @param inputMeasure
	 * @param targetMeasure
	 * @param inputNumericVal
	 * @param studentResponse
	 * @param output
	 * @return
	 */
	private static String calculate(String inputMeasure, String targetMeasure, float inputNumericVal, String studentResponse, String output) {
		//Check if its temperature or Volume
		if(isItTemparature(inputMeasure.toLowerCase(), targetMeasure.toLowerCase())){
			output = convertTemparature(inputMeasure, targetMeasure, inputNumericVal, studentResponse);
		}else if (isItVolume(inputMeasure.toLowerCase(), targetMeasure.toLowerCase())){
			output = convertVolume(inputMeasure, targetMeasure, inputNumericVal, studentResponse);
		}
		
		return output;
	}
	
	/**
	 * To convert the temparature
	 * @return
	 */
	private static String convertTemparature(String inputMeasure, String targetMeasure, float inputNumericVal, String studentResponse){
		String output = DEFAULT_STATUS;
		
		switch(inputMeasure){
			case "kelvin":
				break;
			case "celsius":
				inputNumericVal = (float) (inputNumericVal + 273.15); 
				break;
			case "fahrenheit":
				inputNumericVal = (float) (273.5f + ((inputNumericVal - 32.0f) * (5.0f/9.0f))); 
				break;
			case "rankine":
				inputNumericVal = (float) (inputNumericVal*5f/9f); 
				break;
			default:
				return output;
		}
		
		output = convertToTargetMeasure(inputMeasure, targetMeasure, inputNumericVal);
		
		return output;
	}
	
	
	private static String convertToTargetMeasure(String inputMeasure, String targetMeasure, float inputNumericVal){
		float output;
		
		switch(targetMeasure){
			case "kelvin":
				output = inputNumericVal;
				break;
			case "celsius":
				output = (float) (inputNumericVal - 273.15f); 
				break;
			case "fahrenheit":
				output = (float) (inputNumericVal*9f/5f-459.67f); 
				break;
			case "rankine":
				output = (float) (inputNumericVal*9f/5f); 
				break;
			default:
				return DEFAULT_STATUS;
		}
		
		return output+"";
	}
	
	/**
	 * To convert the temparature
	 * @return
	 */
	private static String convertVolume(String inputMeasure, String targetMeasure, float inputNumericVal, String studentResponse){
		String output = DEFAULT_STATUS;
		
		switch(inputMeasure){
			case "liters":
				break;
			case "tablespoons":
				inputNumericVal = (float) (inputNumericVal/67.628f); 
				break;
			case "cubic-inches":
				inputNumericVal = (float) (inputNumericVal/61.024f); 
				break;
			case "cups":
				inputNumericVal = (float) (inputNumericVal/4.227f); 
				break;
			case "cubic-feet":
				inputNumericVal = (float) (inputNumericVal*28.317f); 
				break;
			case "gallons":
				inputNumericVal = (float) (inputNumericVal*3.785f); 
				break;
			default:
				return output;
		}
		
		output = convertToTargetMeasureForVolume(inputMeasure, targetMeasure, inputNumericVal);
		
		return output;
	}
	
	private static String convertToTargetMeasureForVolume(String inputMeasure, String targetMeasure, float inputNumericVal){
		float output;
		
		switch(targetMeasure){
			case "liters":
				output = (float) inputNumericVal;
				break;
			case "tablespoons":
				output = (float) (inputNumericVal * 67.628f); 
				break;
			case "cubic-inches":
				output = (float) (inputNumericVal * 61.024f); 
				break;
			case "cups":
				output = (float) (inputNumericVal * 4.227f); 
				break;
			case "cubic-feet":
				output = (float) (inputNumericVal/28.317f); 
				break;
			case "gallons":
				output = (float) (inputNumericVal/3.785f); 
				break;
			default:
				return DEFAULT_STATUS;
		}
		
		
		return output+"";
	}
	
	
	
	/**
	 * Check if the input source and target source belongs to temparatures
	 * @param inputMeasure
	 * @param targetMeasure
	 * @return
	 */
	private static boolean isItTemparature(String inputMeasure, String targetMeasure){
		boolean isitTemparature = Arrays.stream(temparatures).anyMatch(inputMeasure::equals);
		
		if(isitTemparature == true){
			isitTemparature = Arrays.stream(temparatures).anyMatch(targetMeasure::equals);
		}
		
		return isitTemparature;
		
	}
	
	/**
	 * Check if the input source and destination source belongs to volumes or not
	 * @param inputMeasure
	 * @param targetMeasure
	 * @return
	 */
	private static boolean isItVolume(String inputMeasure, String targetMeasure){
		boolean isItVolume = Arrays.stream(volumes).anyMatch(inputMeasure::equals);
		
		if(isItVolume == true){
			isItVolume = Arrays.stream(volumes).anyMatch(targetMeasure::equals);
		}
		
		return isItVolume;
		
	}
}


