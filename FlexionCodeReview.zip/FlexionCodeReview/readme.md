FlexionCodeReview

**Pending Features**

N/A


**Externalize Property Files**

N/A

**Maven Commands**

**Compile** 

 $ mvn clean compile


** Test main class for now **
 mvn exec:java -Dexec.mainClass="com.test.flexion.FlexionCodeReviewMain"